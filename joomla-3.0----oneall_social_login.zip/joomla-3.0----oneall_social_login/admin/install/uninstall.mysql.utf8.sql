DROP TABLE IF EXISTS `#__oasl_settings`;
DROP TABLE IF EXISTS `#__oasl_user_mapping`;